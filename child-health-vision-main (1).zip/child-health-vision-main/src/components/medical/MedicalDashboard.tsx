import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Activity, 
  Camera, 
  FileText, 
  Heart, 
  Mic, 
  Stethoscope,
  TrendingUp,
  Users,
  AlertTriangle,
  CheckCircle,
  Brain,
  Thermometer
} from "lucide-react";
import { HealthDataInput } from "./HealthDataInput";
import { ImageScanner } from "./ImageScanner";
import { VoiceAssistant } from "./VoiceAssistant";
import { ComprehensiveResults } from "./ComprehensiveResults";
import { analyzeChildHealth, ChildHealthData, ComprehensiveAnalysisResult } from "@/lib/healthAnalysis";
import heroImage from "@/assets/medical-hero.jpg";

export function MedicalDashboard() {
  const [activeTab, setActiveTab] = useState<"dashboard" | "data-input" | "scanner" | "results">("dashboard");
  const [childData, setChildData] = useState<ChildHealthData | null>(null);
  const [analysisResult, setAnalysisResult] = useState<ComprehensiveAnalysisResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const handleDataAnalysis = async (data: ChildHealthData) => {
    setIsAnalyzing(true);
    setChildData(data);
    
    // Simulate processing time
    await new Promise(resolve => setTimeout(resolve, 2500));
    
    // Run comprehensive health analysis
    const result = analyzeChildHealth(data);
    
    setAnalysisResult(result);
    setIsAnalyzing(false);
    setActiveTab("results");
  };

  const handleNewAssessment = () => {
    setChildData(null);
    setAnalysisResult(null);
    setActiveTab("data-input");
  };

  const stats = [
    {
      title: "Children Assessed",
      value: "1,247",
      change: "+12%",
      icon: Users,
      color: "text-primary"
    },
    {
      title: "High Risk Cases",
      value: "23",
      change: "-8%",
      icon: AlertTriangle,
      color: "text-destructive"
    },
    {
      title: "Recovery Rate",
      value: "94.2%",
      change: "+5.1%",
      icon: TrendingUp,
      color: "text-accent"
    },
    {
      title: "Active Monitoring",
      value: "156",
      change: "+18%",
      icon: Activity,
      color: "text-warning"
    }
  ];

  const healthCategories = [
    { icon: Heart, label: "Nutrition", color: "text-red-500" },
    { icon: Activity, label: "Growth", color: "text-blue-500" },
    { icon: Thermometer, label: "Illness", color: "text-orange-500" },
    { icon: Brain, label: "Behavioral", color: "text-purple-500" }
  ];

  return (
    <div className="min-h-screen bg-gradient-subtle">
      {/* Header */}
      <div className="bg-gradient-primary text-primary-foreground shadow-[var(--shadow-medical)] relative overflow-hidden">
        <div 
          className="absolute inset-0 opacity-10 bg-cover bg-center"
          style={{ backgroundImage: `url(${heroImage})` }}
        />
        <div className="max-w-7xl mx-auto p-6 relative z-10">
          <div className="flex items-center gap-3 mb-2">
            <Stethoscope className="h-8 w-8" />
            <h1 className="text-3xl font-bold">MedAI Child Health</h1>
          </div>
          <p className="text-primary-foreground/90">
            AI-Powered Comprehensive Child Health Analysis & Early Prediction System
          </p>
          <div className="flex gap-4 mt-3">
            {healthCategories.map((cat, i) => (
              <div key={i} className="flex items-center gap-1 text-sm opacity-90">
                <cat.icon className="h-4 w-4" />
                <span>{cat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex gap-1 py-2">
            {[
              { id: "dashboard", label: "Dashboard", icon: Activity },
              { id: "data-input", label: "Data Analysis", icon: FileText },
              { id: "scanner", label: "Image Scanner", icon: Camera },
              { id: "results", label: "Results", icon: CheckCircle }
            ].map(({ id, label, icon: Icon }) => (
              <Button
                key={id}
                variant={activeTab === id ? "default" : "ghost"}
                onClick={() => setActiveTab(id as typeof activeTab)}
                className="flex items-center gap-2"
              >
                <Icon className="h-4 w-4" />
                {label}
              </Button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        {/* Dashboard View */}
        {activeTab === "dashboard" && (
          <div className="space-y-6 animate-fade-in">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {stats.map((stat, index) => (
                <Card key={index} className="medical-card">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">{stat.title}</p>
                        <p className="text-2xl font-bold">{stat.value}</p>
                        <p className={`text-sm ${stat.color}`}>{stat.change} from last month</p>
                      </div>
                      <stat.icon className={`h-8 w-8 ${stat.color}`} />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Quick Actions */}
            <Card className="medical-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-primary" />
                  Quick Actions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Button 
                    onClick={() => setActiveTab("data-input")}
                    className="h-24 flex-col gap-2 bg-gradient-primary hover:opacity-90"
                  >
                    <FileText className="h-8 w-8" />
                    Analyze Child Data
                  </Button>
                  <Button 
                    onClick={() => setActiveTab("scanner")}
                    variant="secondary"
                    className="h-24 flex-col gap-2"
                  >
                    <Camera className="h-8 w-8" />
                    Image Scanner
                  </Button>
                  <Button 
                    variant="outline"
                    className="h-24 flex-col gap-2"
                  >
                    <Mic className="h-8 w-8" />
                    Voice Assistant
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Recent Activities */}
            <Card className="medical-card">
              <CardHeader>
                <CardTitle>Recent Assessments</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { name: "Sarah M.", age: 3, status: "low", time: "2 hours ago" },
                    { name: "Ahmed K.", age: 2, status: "moderate", time: "5 hours ago" },
                    { name: "Maria L.", age: 4, status: "low", time: "1 day ago" }
                  ].map((child, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                      <div>
                        <p className="font-medium">{child.name}</p>
                        <p className="text-sm text-muted-foreground">Age: {child.age} years</p>
                      </div>
                      <div className="flex items-center gap-3">
                        <Badge 
                          variant={child.status === "low" ? "default" : child.status === "moderate" ? "secondary" : "destructive"}
                        >
                          {child.status === "low" ? "Low Risk" : child.status === "moderate" ? "Moderate Risk" : "High Risk"}
                        </Badge>
                        <span className="text-sm text-muted-foreground">{child.time}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Data Input View */}
        {activeTab === "data-input" && (
          <div className="animate-slide-up">
            <HealthDataInput onAnalyze={handleDataAnalysis} isAnalyzing={isAnalyzing} />
          </div>
        )}

        {/* Image Scanner View */}
        {activeTab === "scanner" && (
          <div className="animate-slide-up">
            <ImageScanner onAnalysis={setAnalysisResult} />
          </div>
        )}

        {/* Results View */}
        {activeTab === "results" && (
          <div className="animate-slide-up">
            {analysisResult && childData ? (
              <ComprehensiveResults 
                result={analysisResult} 
                childData={childData}
                onNewAssessment={handleNewAssessment}
              />
            ) : (
              <Card className="medical-card text-center py-12">
                <CardContent>
                  <FileText className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <p className="text-lg text-muted-foreground">No analysis results yet</p>
                  <p className="text-sm text-muted-foreground">
                    Complete a comprehensive health assessment to view results
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </div>

      {/* Voice Assistant - Always Available */}
      <VoiceAssistant childData={childData} analysisResult={analysisResult} />
    </div>
  );
}