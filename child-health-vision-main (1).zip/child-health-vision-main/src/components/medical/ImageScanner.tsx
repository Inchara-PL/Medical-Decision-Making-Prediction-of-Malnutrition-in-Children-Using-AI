import { useState, useRef, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Camera, 
  Upload, 
  Scan, 
  AlertCircle, 
  CheckCircle, 
  Loader2, 
  RefreshCw,
  Eye,
  FileImage
} from "lucide-react";
import Webcam from "react-webcam";
import { ComprehensiveAnalysisResult } from "@/lib/healthAnalysis";

interface ImageScannerProps {
  onAnalysis: (result: ComprehensiveAnalysisResult) => void;
}

export function ImageScanner({ onAnalysis }: ImageScannerProps) {
  const [isScanning, setIsScanning] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [showCamera, setShowCamera] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [error, setError] = useState<string>("");
  const webcamRef = useRef<Webcam>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const videoConstraints = {
    width: 1280,
    height: 720,
    facingMode: "user"
  };

  const capture = useCallback(() => {
    const imageSrc = webcamRef.current?.getScreenshot();
    if (imageSrc) {
      setCapturedImage(imageSrc);
      setShowCamera(false);
    }
  }, [webcamRef]);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 10 * 1024 * 1024) { // 10MB limit
        setError("File size must be less than 10MB");
        return;
      }
      
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setUploadedImage(result);
        setCapturedImage(null);
        setError("");
      };
      reader.readAsDataURL(file);
    }
  };

  const analyzeImage = async () => {
    const imageToAnalyze = capturedImage || uploadedImage;
    if (!imageToAnalyze) return;

    setIsScanning(true);
    setScanProgress(0);
    setError("");

    try {
      // Simulate AI image analysis with progress updates
      const progressSteps = [
        { progress: 20, message: "Preprocessing image..." },
        { progress: 40, message: "Detecting facial features..." },
        { progress: 60, message: "Analyzing body composition..." },
        { progress: 80, message: "Calculating nutritional indicators..." },
        { progress: 95, message: "Generating assessment..." },
        { progress: 100, message: "Analysis complete!" }
      ];

      for (const step of progressSteps) {
        await new Promise(resolve => setTimeout(resolve, 800));
        setScanProgress(step.progress);
      }

      // Generate comprehensive analysis results from image
      const riskFactors = Math.random();
      let overallRiskLevel: "low" | "moderate" | "high";
      let nutritionalStatus: string;
      let recommendations: string[];

      if (riskFactors < 0.3) {
        overallRiskLevel = "high";
        nutritionalStatus = "Possible Severe Acute Malnutrition";
        recommendations = [
          "Urgent medical evaluation required",
          "Immediate nutritional intervention",
          "Monitor for complications",
          "Family support and education needed"
        ];
      } else if (riskFactors < 0.6) {
        overallRiskLevel = "moderate";
        nutritionalStatus = "Signs of Moderate Malnutrition";
        recommendations = [
          "Schedule follow-up assessment",
          "Nutritional supplementation advised",
          "Growth monitoring required",
          "Dietary guidance for caregivers"
        ];
      } else {
        overallRiskLevel = "low";
        nutritionalStatus = "Normal Nutritional Status";
        recommendations = [
          "Continue regular health checks",
          "Maintain current feeding practices",
          "Monitor growth milestones",
          "Preventive care recommended"
        ];
      }

      const result: ComprehensiveAnalysisResult = {
        overallRiskLevel,
        confidence: Math.floor(Math.random() * 20) + 75,
        nutritionalStatus,
        recommendations,
        categories: [
          {
            category: "Visual Assessment",
            status: overallRiskLevel === "high" ? "critical" : overallRiskLevel === "moderate" ? "concern" : "healthy",
            score: riskFactors < 0.3 ? 0.8 : riskFactors < 0.6 ? 0.5 : 0.1,
            findings: ["Image-based nutritional assessment completed"]
          }
        ],
        riskAlerts: overallRiskLevel === "high" ? [{
          level: "urgent" as const,
          title: "Visual Signs of Malnutrition",
          description: "Image analysis indicates potential severe malnutrition signs",
          actionRequired: true
        }] : [],
        preventionTips: [{
          category: "Nutrition",
          tip: "Ensure balanced diet with adequate protein and calories",
          priority: "high" as const
        }],
        treatmentSuggestions: overallRiskLevel !== "low" ? [{
          condition: "Nutritional Concern",
          homeRemedies: ["Increase caloric intake", "Add protein-rich foods"],
          whenToSeeDoctor: "Schedule assessment within 1-2 weeks",
          urgency: overallRiskLevel === "high" ? "immediate" as const : "soon" as const
        }] : []
      };

      onAnalysis(result);

    } catch (err) {
      setError("Analysis failed. Please try again.");
      console.error("Image analysis error:", err);
    } finally {
      setIsScanning(false);
      setScanProgress(0);
    }
  };

  const resetScanner = () => {
    setCapturedImage(null);
    setUploadedImage(null);
    setShowCamera(false);
    setError("");
    setScanProgress(0);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Card className="medical-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Scan className="h-5 w-5 text-primary" />
            AI Image Analysis Scanner
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Image Capture Options */}
          {!capturedImage && !uploadedImage && !showCamera && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Button
                onClick={() => setShowCamera(true)}
                className="h-32 flex-col gap-3 bg-gradient-primary hover:opacity-90"
                size="lg"
              >
                <Camera className="h-8 w-8" />
                <div className="text-center">
                  <div className="font-medium">Take Photo</div>
                  <div className="text-sm opacity-90">Use device camera</div>
                </div>
              </Button>
              
              <Button
                onClick={() => fileInputRef.current?.click()}
                variant="secondary"
                className="h-32 flex-col gap-3"
                size="lg"
              >
                <Upload className="h-8 w-8" />
                <div className="text-center">
                  <div className="font-medium">Upload Image</div>
                  <div className="text-sm opacity-70">Select from device</div>
                </div>
              </Button>
            </div>
          )}

          {/* Hidden File Input */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileUpload}
            className="hidden"
          />

          {/* Camera View */}
          {showCamera && (
            <div className="space-y-4">
              <div className="relative rounded-lg overflow-hidden bg-black">
                <Webcam
                  ref={webcamRef}
                  audio={false}
                  screenshotFormat="image/jpeg"
                  videoConstraints={videoConstraints}
                  className="w-full h-auto"
                />
                <div className="absolute inset-0 border-2 border-primary/50 rounded-lg pointer-events-none">
                  <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                    <div className="w-64 h-64 border-2 border-primary/70 rounded-lg"></div>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-center gap-3">
                <Button onClick={capture} className="bg-gradient-primary hover:opacity-90">
                  <Camera className="h-4 w-4 mr-2" />
                  Capture Photo
                </Button>
                <Button onClick={() => setShowCamera(false)} variant="outline">
                  Cancel
                </Button>
              </div>
            </div>
          )}

          {/* Image Preview */}
          {(capturedImage || uploadedImage) && (
            <div className="space-y-4">
              <div className="relative">
                <img
                  src={capturedImage || uploadedImage || ""}
                  alt="Captured for analysis"
                  className="w-full max-h-96 object-contain rounded-lg border"
                />
                <div className="absolute top-4 right-4 bg-card/90 backdrop-blur-sm rounded-lg p-2">
                  <Eye className="h-5 w-5 text-primary" />
                </div>
              </div>
              
              <div className="flex justify-center gap-3">
                <Button 
                  onClick={analyzeImage}
                  disabled={isScanning}
                  className="bg-gradient-primary hover:opacity-90"
                >
                  {isScanning ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Scan className="h-4 w-4 mr-2" />
                      Analyze Image
                    </>
                  )}
                </Button>
                <Button onClick={resetScanner} variant="outline">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Try Again
                </Button>
              </div>
            </div>
          )}

          {/* Analysis Progress */}
          {isScanning && (
            <Card className="bg-muted/50">
              <CardContent className="py-6">
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <Loader2 className="h-6 w-6 text-primary animate-spin" />
                    <h3 className="text-lg font-medium">AI Image Analysis in Progress</h3>
                  </div>
                  <Progress value={scanProgress} className="h-2" />
                  <p className="text-sm text-muted-foreground">
                    Using advanced computer vision algorithms to assess nutritional indicators...
                  </p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Error Display */}
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Instructions */}
          <Alert>
            <FileImage className="h-4 w-4" />
            <AlertDescription>
              <strong>Photography Tips:</strong>
              <ul className="mt-2 ml-4 list-disc space-y-1 text-sm">
                <li>Ensure good lighting and clear visibility of the child</li>
                <li>Include full body view when possible for better assessment</li>
                <li>Avoid shadows or obscured areas</li>
                <li>Hold camera steady for sharp, clear images</li>
              </ul>
            </AlertDescription>
          </Alert>

          {/* Disclaimer */}
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              <strong>Important:</strong> Image analysis provides preliminary assessment only. 
              Clinical examination and proper measurements are essential for accurate diagnosis.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    </div>
  );
}