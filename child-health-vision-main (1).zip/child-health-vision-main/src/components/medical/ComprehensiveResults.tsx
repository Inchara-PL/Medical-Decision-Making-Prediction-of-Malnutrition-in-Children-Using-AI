import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { 
  CheckCircle, 
  AlertTriangle, 
  XCircle, 
  Activity,
  Heart,
  Brain,
  Thermometer,
  Shield,
  Lightbulb,
  Stethoscope,
  Clock,
  Download,
  Share2,
  FileText,
  AlertCircle,
  Info
} from "lucide-react";
import { ComprehensiveAnalysisResult, ChildHealthData } from "@/lib/healthAnalysis";

interface ComprehensiveResultsProps {
  result: ComprehensiveAnalysisResult;
  childData: ChildHealthData;
  onNewAssessment: () => void;
}

export function ComprehensiveResults({ result, childData, onNewAssessment }: ComprehensiveResultsProps) {
  const bmi = (childData.weight / ((childData.height / 100) ** 2));

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "healthy": return <CheckCircle className="h-5 w-5 text-accent" />;
      case "attention": return <Info className="h-5 w-5 text-blue-500" />;
      case "concern": return <AlertTriangle className="h-5 w-5 text-warning" />;
      case "critical": return <XCircle className="h-5 w-5 text-destructive" />;
      default: return <Activity className="h-5 w-5" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "healthy": return <Badge className="bg-accent text-accent-foreground">Healthy</Badge>;
      case "attention": return <Badge className="bg-blue-500 text-white">Needs Attention</Badge>;
      case "concern": return <Badge className="bg-warning text-warning-foreground">Concern</Badge>;
      case "critical": return <Badge className="bg-destructive text-destructive-foreground">Critical</Badge>;
      default: return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "Nutrition": return <Heart className="h-5 w-5" />;
      case "Growth & Development": return <Activity className="h-5 w-5" />;
      case "Common Illnesses": return <Thermometer className="h-5 w-5" />;
      case "Mental & Behavioral": return <Brain className="h-5 w-5" />;
      default: return <Activity className="h-5 w-5" />;
    }
  };

  const getAlertIcon = (level: string) => {
    switch (level) {
      case "urgent": return <XCircle className="h-4 w-4 text-destructive" />;
      case "warning": return <AlertTriangle className="h-4 w-4 text-warning" />;
      default: return <Info className="h-4 w-4 text-blue-500" />;
    }
  };

  const getUrgencyBadge = (urgency: string) => {
    switch (urgency) {
      case "immediate": return <Badge className="bg-destructive text-destructive-foreground">Immediate</Badge>;
      case "soon": return <Badge className="bg-warning text-warning-foreground">Soon</Badge>;
      default: return <Badge variant="secondary">Routine</Badge>;
    }
  };

  const formatDate = () => {
    return new Date().toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header Card */}
      <Card className="medical-card">
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-4">
            <CardTitle className="flex items-center gap-3">
              {result.overallRiskLevel === "low" && <CheckCircle className="h-6 w-6 text-accent" />}
              {result.overallRiskLevel === "moderate" && <AlertTriangle className="h-6 w-6 text-warning" />}
              {result.overallRiskLevel === "high" && <XCircle className="h-6 w-6 text-destructive" />}
              Health Assessment for {childData.name}
            </CardTitle>
            <Badge 
              className={
                result.overallRiskLevel === "low" ? "bg-accent text-accent-foreground" :
                result.overallRiskLevel === "moderate" ? "bg-warning text-warning-foreground" :
                "bg-destructive text-destructive-foreground"
              }
            >
              {result.overallRiskLevel.charAt(0).toUpperCase() + result.overallRiskLevel.slice(1)} Risk
            </Badge>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Clock className="h-4 w-4" />
            Assessment completed on {formatDate()}
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div className="text-center p-3 bg-muted rounded-lg">
              <p className="text-muted-foreground">Age</p>
              <p className="font-semibold">{childData.age} years</p>
            </div>
            <div className="text-center p-3 bg-muted rounded-lg">
              <p className="text-muted-foreground">Height</p>
              <p className="font-semibold">{childData.height} cm</p>
            </div>
            <div className="text-center p-3 bg-muted rounded-lg">
              <p className="text-muted-foreground">Weight</p>
              <p className="font-semibold">{childData.weight} kg</p>
            </div>
            <div className="text-center p-3 bg-muted rounded-lg">
              <p className="text-muted-foreground">BMI</p>
              <p className="font-semibold">{bmi.toFixed(1)}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Risk Alerts */}
      {result.riskAlerts.length > 0 && (
        <Card className="medical-card border-l-4 border-l-warning">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <AlertTriangle className="h-5 w-5 text-warning" />
              Risk Alerts ({result.riskAlerts.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {result.riskAlerts.map((alert, index) => (
              <div 
                key={index} 
                className={`p-4 rounded-lg border ${
                  alert.level === "urgent" ? "bg-destructive/10 border-destructive/30" :
                  alert.level === "warning" ? "bg-warning/10 border-warning/30" :
                  "bg-blue-50 border-blue-200 dark:bg-blue-950/20 dark:border-blue-800"
                }`}
              >
                <div className="flex items-start gap-3">
                  {getAlertIcon(alert.level)}
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium">{alert.title}</span>
                      {alert.actionRequired && (
                        <Badge variant="outline" className="text-xs">Action Required</Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">{alert.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Health Categories */}
      <Card className="medical-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-primary" />
            Health Category Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Accordion type="multiple" className="w-full">
            {result.categories.map((category, index) => (
              <AccordionItem key={index} value={`category-${index}`}>
                <AccordionTrigger className="hover:no-underline">
                  <div className="flex items-center gap-3 flex-1">
                    <div className="p-2 bg-primary/10 rounded-lg text-primary">
                      {getCategoryIcon(category.category)}
                    </div>
                    <div className="flex-1 text-left">
                      <p className="font-medium">{category.category}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Progress value={(1 - category.score) * 100} className="h-2 w-24" />
                        <span className="text-xs text-muted-foreground">
                          {Math.round((1 - category.score) * 100)}% healthy
                        </span>
                      </div>
                    </div>
                    {getStatusBadge(category.status)}
                  </div>
                </AccordionTrigger>
                <AccordionContent>
                  <div className="pl-12 space-y-2">
                    {category.findings.map((finding, fIndex) => (
                      <div key={fIndex} className="flex items-start gap-2 text-sm">
                        {getStatusIcon(category.status)}
                        <span>{finding}</span>
                      </div>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </CardContent>
      </Card>

      {/* Prevention Tips */}
      <Card className="medical-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lightbulb className="h-5 w-5 text-accent" />
            Prevention Tips
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {result.preventionTips.map((tip, index) => (
              <div 
                key={index} 
                className={`p-4 rounded-lg border ${
                  tip.priority === "high" ? "bg-accent/10 border-accent/30" :
                  tip.priority === "medium" ? "bg-primary/5 border-primary/20" :
                  "bg-muted border-muted-foreground/20"
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className={`w-2 h-2 rounded-full mt-2 ${
                    tip.priority === "high" ? "bg-accent" :
                    tip.priority === "medium" ? "bg-primary" :
                    "bg-muted-foreground"
                  }`} />
                  <div>
                    <span className="text-xs font-medium text-muted-foreground uppercase">
                      {tip.category}
                    </span>
                    <p className="text-sm mt-1">{tip.tip}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Treatment Suggestions */}
      {result.treatmentSuggestions.length > 0 && (
        <Card className="medical-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Stethoscope className="h-5 w-5 text-primary" />
              Treatment Suggestions
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {result.treatmentSuggestions.map((treatment, index) => (
              <div key={index} className="p-4 bg-muted/50 rounded-lg space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium">{treatment.condition}</h4>
                  {getUrgencyBadge(treatment.urgency)}
                </div>
                
                <div>
                  <p className="text-sm font-medium mb-2">Home Remedies:</p>
                  <ul className="space-y-1">
                    {treatment.homeRemedies.map((remedy, rIndex) => (
                      <li key={rIndex} className="text-sm text-muted-foreground flex items-start gap-2">
                        <CheckCircle className="h-4 w-4 text-accent mt-0.5 flex-shrink-0" />
                        {remedy}
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className="pt-2 border-t">
                  <p className="text-sm">
                    <span className="font-medium">When to see a doctor: </span>
                    <span className="text-muted-foreground">{treatment.whenToSeeDoctor}</span>
                  </p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Recommendations */}
      <Card className="medical-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            Clinical Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {result.recommendations.map((recommendation, index) => (
              <div key={index} className="flex items-start gap-3 p-3 bg-muted/50 rounded-lg">
                <div className="w-6 h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-medium flex-shrink-0">
                  {index + 1}
                </div>
                <p className="text-sm flex-1">{recommendation}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Disclaimer */}
      <Alert className="border-warning/50 bg-warning/5">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          <strong>Medical Disclaimer:</strong> This AI assessment is for screening purposes only and should not replace professional medical diagnosis. 
          Always consult qualified healthcare professionals for comprehensive evaluation, diagnosis, and treatment planning. 
          In emergency situations, seek immediate medical attention.
        </AlertDescription>
      </Alert>

      {/* Action Buttons */}
      <div className="flex justify-center gap-3 flex-wrap">
        <Button variant="outline" className="flex items-center gap-2">
          <Download className="h-4 w-4" />
          Download Report
        </Button>
        <Button variant="outline" className="flex items-center gap-2">
          <Share2 className="h-4 w-4" />
          Share Results
        </Button>
        <Button 
          onClick={onNewAssessment}
          className="bg-gradient-primary hover:opacity-90 flex items-center gap-2"
        >
          <FileText className="h-4 w-4" />
          New Assessment
        </Button>
      </div>
    </div>
  );
}
