import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { FileText, Calculator, Loader2, AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface ChildData {
  name: string;
  age: number;
  height: number;
  weight: number;
  armCircumference: number;
  additionalNotes: string;
}

interface DataInputProps {
  onAnalyze: (data: ChildData) => void;
  isAnalyzing: boolean;
}

export function DataInput({ onAnalyze, isAnalyzing }: DataInputProps) {
  const [formData, setFormData] = useState<ChildData>({
    name: "",
    age: 0,
    height: 0,
    weight: 0,
    armCircumference: 0,
    additionalNotes: ""
  });
  
  const [errors, setErrors] = useState<Partial<Record<keyof ChildData, string>>>({});

  const validateForm = () => {
    const newErrors: Partial<Record<keyof ChildData, string>> = {};
    
    if (!formData.name.trim()) newErrors.name = "Name is required";
    if (formData.age <= 0 || formData.age > 18) newErrors.age = "Age must be between 1-18 years";
    if (formData.height <= 0 || formData.height > 200) newErrors.height = "Height must be between 1-200 cm";
    if (formData.weight <= 0 || formData.weight > 100) newErrors.weight = "Weight must be between 1-100 kg";
    if (formData.armCircumference <= 0 || formData.armCircumference > 30) {
      newErrors.armCircumference = "Arm circumference must be between 1-30 cm";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onAnalyze(formData);
    }
  };

  const updateField = (field: keyof ChildData, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  // Calculate BMI for preview
  const bmi = formData.height > 0 && formData.weight > 0 
    ? (formData.weight / ((formData.height / 100) ** 2)).toFixed(1) 
    : null;

  const completionPercentage = Math.round(
    (Object.values(formData).filter((value, index) => 
      index !== 5 && (typeof value === 'string' ? value.trim() !== '' : value > 0)
    ).length / 5) * 100
  );

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Card className="medical-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            Child Assessment Data Entry
          </CardTitle>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Form Completion</span>
              <span>{completionPercentage}%</span>
            </div>
            <Progress value={completionPercentage} className="h-2" />
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Basic Information */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium flex items-center gap-2">
                  <span className="w-6 h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm">1</span>
                  Basic Information
                </h3>
                
                <div className="space-y-2">
                  <Label htmlFor="name">Child's Name *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => updateField("name", e.target.value)}
                    placeholder="Enter child's name"
                    className={errors.name ? "border-destructive" : ""}
                  />
                  {errors.name && <p className="text-sm text-destructive">{errors.name}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="age">Age (years) *</Label>
                  <Input
                    id="age"
                    type="number"
                    min="1"
                    max="18"
                    value={formData.age || ""}
                    onChange={(e) => updateField("age", parseFloat(e.target.value) || 0)}
                    placeholder="Enter age in years"
                    className={errors.age ? "border-destructive" : ""}
                  />
                  {errors.age && <p className="text-sm text-destructive">{errors.age}</p>}
                </div>
              </div>

              {/* Anthropometric Measurements */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium flex items-center gap-2">
                  <span className="w-6 h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm">2</span>
                  Measurements
                </h3>
                
                <div className="space-y-2">
                  <Label htmlFor="height">Height (cm) *</Label>
                  <Input
                    id="height"
                    type="number"
                    min="1"
                    max="200"
                    step="0.1"
                    value={formData.height || ""}
                    onChange={(e) => updateField("height", parseFloat(e.target.value) || 0)}
                    placeholder="Enter height in cm"
                    className={errors.height ? "border-destructive" : ""}
                  />
                  {errors.height && <p className="text-sm text-destructive">{errors.height}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="weight">Weight (kg) *</Label>
                  <Input
                    id="weight"
                    type="number"
                    min="1"
                    max="100"
                    step="0.1"
                    value={formData.weight || ""}
                    onChange={(e) => updateField("weight", parseFloat(e.target.value) || 0)}
                    placeholder="Enter weight in kg"
                    className={errors.weight ? "border-destructive" : ""}
                  />
                  {errors.weight && <p className="text-sm text-destructive">{errors.weight}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="armCircumference">Mid-Upper Arm Circumference (cm) *</Label>
                  <Input
                    id="armCircumference"
                    type="number"
                    min="1"
                    max="30"
                    step="0.1"
                    value={formData.armCircumference || ""}
                    onChange={(e) => updateField("armCircumference", parseFloat(e.target.value) || 0)}
                    placeholder="Enter MUAC in cm"
                    className={errors.armCircumference ? "border-destructive" : ""}
                  />
                  {errors.armCircumference && <p className="text-sm text-destructive">{errors.armCircumference}</p>}
                </div>
              </div>
            </div>

            {/* BMI Preview */}
            {bmi && (
              <Alert>
                <Calculator className="h-4 w-4" />
                <AlertDescription>
                  <strong>Calculated BMI:</strong> {bmi} kg/m²
                  {parseFloat(bmi) < 18.5 && " (Below normal range - may indicate undernutrition)"}
                </AlertDescription>
              </Alert>
            )}

            {/* Additional Notes */}
            <div className="space-y-2">
              <Label htmlFor="notes">Additional Notes (Optional)</Label>
              <Textarea
                id="notes"
                value={formData.additionalNotes}
                onChange={(e) => updateField("additionalNotes", e.target.value)}
                placeholder="Any additional observations, symptoms, or relevant information..."
                rows={3}
              />
            </div>

            {/* Important Notice */}
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                <strong>Medical Disclaimer:</strong> This AI system provides assessment support only. 
                Always consult qualified healthcare professionals for diagnosis and treatment decisions.
              </AlertDescription>
            </Alert>

            {/* Submit Button */}
            <div className="flex justify-end gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={() => setFormData({
                  name: "",
                  age: 0,
                  height: 0,
                  weight: 0,
                  armCircumference: 0,
                  additionalNotes: ""
                })}
                disabled={isAnalyzing}
              >
                Clear Form
              </Button>
              <Button 
                type="submit" 
                disabled={isAnalyzing || completionPercentage < 100}
                className="bg-gradient-primary hover:opacity-90 min-w-32"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Calculator className="h-4 w-4 mr-2" />
                    Analyze Data
                  </>
                )}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Analysis Progress */}
      {isAnalyzing && (
        <Card className="medical-card">
          <CardContent className="py-8">
            <div className="text-center space-y-4">
              <div className="flex justify-center">
                <div className="relative">
                  <Loader2 className="h-12 w-12 text-primary animate-spin" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-8 h-8 bg-primary/20 rounded-full animate-pulse"></div>
                  </div>
                </div>
              </div>
              <div className="space-y-2">
                <h3 className="text-lg font-medium">AI Analysis in Progress</h3>
                <p className="text-muted-foreground">
                  Processing anthropometric data and calculating malnutrition risk assessment...
                </p>
              </div>
              <Progress value={85} className="max-w-xs mx-auto" />
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}