import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  CheckCircle, 
  AlertTriangle, 
  XCircle, 
  TrendingUp,
  Activity,
  Heart,
  Scale,
  Ruler,
  FileText,
  Download,
  Share2,
  Clock
} from "lucide-react";

interface ChildData {
  name: string;
  age: number;
  height: number;
  weight: number;
  armCircumference: number;
  additionalNotes: string;
}

interface AnalysisResult {
  riskLevel: "low" | "moderate" | "high";
  confidence: number;
  recommendations: string[];
  nutritionalStatus: string;
}

interface ResultsDisplayProps {
  result: AnalysisResult;
  childData: ChildData;
}

export function ResultsDisplay({ result, childData }: ResultsDisplayProps) {
  // Calculate additional metrics
  const bmi = (childData.weight / ((childData.height / 100) ** 2));
  const bmiCategory = bmi < 16 ? "Severely Underweight" : 
                    bmi < 18.5 ? "Underweight" : 
                    bmi < 25 ? "Normal Weight" : "Overweight";

  const getRiskIcon = (level: string) => {
    switch (level) {
      case "low": return <CheckCircle className="h-6 w-6 text-accent" />;
      case "moderate": return <AlertTriangle className="h-6 w-6 text-warning" />;
      case "high": return <XCircle className="h-6 w-6 text-destructive" />;
      default: return <Activity className="h-6 w-6" />;
    }
  };

  const getRiskBadge = (level: string) => {
    switch (level) {
      case "low": return <Badge className="status-healthy">Low Risk</Badge>;
      case "moderate": return <Badge className="status-warning">Moderate Risk</Badge>;
      case "high": return <Badge className="status-critical">High Risk</Badge>;
      default: return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  const formatDate = () => {
    return new Date().toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header Card */}
      <Card className="medical-card">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-3">
              {getRiskIcon(result.riskLevel)}
              Analysis Results for {childData.name}
            </CardTitle>
            {getRiskBadge(result.riskLevel)}
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Clock className="h-4 w-4" />
            Assessment completed on {formatDate()}
          </div>
        </CardHeader>
      </Card>

      {/* Key Findings */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Nutritional Status */}
        <Card className="medical-card">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Heart className="h-5 w-5 text-primary" />
              Nutritional Assessment
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm font-medium">Status:</span>
                <span className={`text-sm font-medium ${
                  result.riskLevel === 'low' ? 'text-accent' :
                  result.riskLevel === 'moderate' ? 'text-warning' : 'text-destructive'
                }`}>
                  {result.nutritionalStatus}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm font-medium">Confidence Level:</span>
                <span className="text-sm">{result.confidence}%</span>
              </div>
              <Progress 
                value={result.confidence} 
                className="h-2"
              />
            </div>

            <div className="pt-4 border-t">
              <h4 className="text-sm font-medium mb-3">Key Measurements:</h4>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <Ruler className="h-4 w-4 text-muted-foreground" />
                  <span>Height: {childData.height} cm</span>
                </div>
                <div className="flex items-center gap-2">
                  <Scale className="h-4 w-4 text-muted-foreground" />
                  <span>Weight: {childData.weight} kg</span>
                </div>
                <div className="flex items-center gap-2">
                  <Activity className="h-4 w-4 text-muted-foreground" />
                  <span>BMI: {bmi.toFixed(1)} kg/m²</span>
                </div>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                  <span>MUAC: {childData.armCircumference} cm</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Risk Assessment */}
        <Card className="medical-card">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-primary" />
              Risk Assessment
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center py-4">
              <div className="flex justify-center mb-3">
                {getRiskIcon(result.riskLevel)}
              </div>
              <div className="text-2xl font-bold mb-1">
                {result.riskLevel.charAt(0).toUpperCase() + result.riskLevel.slice(1)} Risk
              </div>
              <div className="text-sm text-muted-foreground">
                Malnutrition Risk Level
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span>BMI Category:</span>
                <span className="font-medium">{bmiCategory}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Age Group:</span>
                <span className="font-medium">{childData.age} years old</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Assessment Method:</span>
                <span className="font-medium">AI-Powered Analysis</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recommendations */}
      <Card className="medical-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            Clinical Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {result.recommendations.map((recommendation, index) => (
              <div key={index} className="flex items-start gap-3 p-3 bg-muted/50 rounded-lg">
                <div className="w-6 h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-medium flex-shrink-0">
                  {index + 1}
                </div>
                <p className="text-sm flex-1">{recommendation}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Additional Notes */}
      {childData.additionalNotes && (
        <Card className="medical-card">
          <CardHeader>
            <CardTitle className="text-lg">Additional Notes</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              {childData.additionalNotes}
            </p>
          </CardContent>
        </Card>
      )}

      {/* Important Disclaimer */}
      <Alert className="border-warning/50 bg-warning/5">
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          <strong>Medical Disclaimer:</strong> This AI assessment is for screening purposes only and should not replace professional medical diagnosis. 
          Always consult qualified healthcare professionals for comprehensive evaluation, diagnosis, and treatment planning. 
          In emergency situations or severe malnutrition cases, seek immediate medical attention.
        </AlertDescription>
      </Alert>

      {/* Action Buttons */}
      <div className="flex justify-center gap-3">
        <Button variant="outline" className="flex items-center gap-2">
          <Download className="h-4 w-4" />
          Download Report
        </Button>
        <Button variant="outline" className="flex items-center gap-2">
          <Share2 className="h-4 w-4" />
          Share Results
        </Button>
        <Button className="bg-gradient-primary hover:opacity-90 flex items-center gap-2">
          <FileText className="h-4 w-4" />
          New Assessment
        </Button>
      </div>
    </div>
  );
}