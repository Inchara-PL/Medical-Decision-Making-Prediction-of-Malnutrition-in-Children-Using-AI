import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  FileText, 
  Calculator, 
  Loader2, 
  AlertCircle,
  Heart,
  Brain,
  Thermometer,
  Activity
} from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ChildHealthData } from "@/lib/healthAnalysis";

interface HealthDataInputProps {
  onAnalyze: (data: ChildHealthData) => void;
  isAnalyzing: boolean;
}

const symptomOptions = [
  { id: "fever", label: "Fever" },
  { id: "cough", label: "Cough" },
  { id: "diarrhea", label: "Diarrhea" },
  { id: "vomiting", label: "Vomiting" },
  { id: "rash", label: "Skin Rash" },
  { id: "fatigue", label: "Fatigue/Tiredness" },
  { id: "headache", label: "Headache" },
  { id: "loss_of_appetite", label: "Loss of Appetite" },
  { id: "runny_nose", label: "Runny Nose" },
  { id: "sore_throat", label: "Sore Throat" },
  { id: "ear_pain", label: "Ear Pain" },
  { id: "stomach_pain", label: "Stomach Pain" }
];

const milestoneOptions = [
  { id: "speech_delay", label: "Speech Delay" },
  { id: "motor_delay", label: "Motor Skills Delay" },
  { id: "walking_late", label: "Walking Late" },
  { id: "social_interaction", label: "Social Interaction Issues" },
  { id: "learning_difficulty", label: "Learning Difficulties" }
];

const behavioralOptions = [
  { id: "hyperactivity", label: "Hyperactivity" },
  { id: "aggression", label: "Aggressive Behavior" },
  { id: "withdrawal", label: "Social Withdrawal" },
  { id: "anxiety", label: "Anxiety/Nervousness" },
  { id: "sleep_problems", label: "Sleep Problems" },
  { id: "eating_issues", label: "Eating Issues" },
  { id: "mood_swings", label: "Mood Swings" }
];

export function HealthDataInput({ onAnalyze, isAnalyzing }: HealthDataInputProps) {
  const [formData, setFormData] = useState<ChildHealthData>({
    name: "",
    age: 0,
    height: 0,
    weight: 0,
    armCircumference: 0,
    additionalNotes: "",
    symptoms: [],
    temperature: undefined,
    milestonesConcerns: [],
    behavioralObservations: [],
    sleepHours: undefined,
    appetiteLevel: "normal"
  });
  
  const [errors, setErrors] = useState<Partial<Record<string, string>>>({});
  const [activeTab, setActiveTab] = useState("basic");

  const validateForm = () => {
    const newErrors: Partial<Record<string, string>> = {};
    
    if (!formData.name.trim()) newErrors.name = "Name is required";
    if (formData.age <= 0 || formData.age > 18) newErrors.age = "Age must be between 1-18 years";
    if (formData.height <= 0 || formData.height > 200) newErrors.height = "Height must be between 1-200 cm";
    if (formData.weight <= 0 || formData.weight > 100) newErrors.weight = "Weight must be between 1-100 kg";
    if (formData.armCircumference <= 0 || formData.armCircumference > 30) {
      newErrors.armCircumference = "Arm circumference must be between 1-30 cm";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onAnalyze(formData);
    }
  };

  const updateField = (field: keyof ChildHealthData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  const toggleArrayItem = (field: "symptoms" | "milestonesConcerns" | "behavioralObservations", item: string) => {
    const currentArray = formData[field] || [];
    const newArray = currentArray.includes(item)
      ? currentArray.filter(i => i !== item)
      : [...currentArray, item];
    updateField(field, newArray);
  };

  const bmi = formData.height > 0 && formData.weight > 0 
    ? (formData.weight / ((formData.height / 100) ** 2)).toFixed(1) 
    : null;

  const basicFieldsFilled = formData.name && formData.age > 0 && formData.height > 0 && formData.weight > 0 && formData.armCircumference > 0;
  const completionPercentage = basicFieldsFilled ? 100 : Math.round(
    ([formData.name, formData.age > 0, formData.height > 0, formData.weight > 0, formData.armCircumference > 0]
      .filter(Boolean).length / 5) * 100
  );

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Card className="medical-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            Comprehensive Child Health Assessment
          </CardTitle>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Required Fields Progress</span>
              <span>{completionPercentage}%</span>
            </div>
            <Progress value={completionPercentage} className="h-2" />
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="basic" className="flex items-center gap-1">
                  <Activity className="h-4 w-4" />
                  <span className="hidden sm:inline">Basic</span>
                </TabsTrigger>
                <TabsTrigger value="growth" className="flex items-center gap-1">
                  <Heart className="h-4 w-4" />
                  <span className="hidden sm:inline">Growth</span>
                </TabsTrigger>
                <TabsTrigger value="illness" className="flex items-center gap-1">
                  <Thermometer className="h-4 w-4" />
                  <span className="hidden sm:inline">Symptoms</span>
                </TabsTrigger>
                <TabsTrigger value="behavioral" className="flex items-center gap-1">
                  <Brain className="h-4 w-4" />
                  <span className="hidden sm:inline">Behavioral</span>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="basic" className="space-y-4 pt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium flex items-center gap-2">
                      <span className="w-6 h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm">1</span>
                      Basic Information
                    </h3>
                    
                    <div className="space-y-2">
                      <Label htmlFor="name">Child's Name *</Label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) => updateField("name", e.target.value)}
                        placeholder="Enter child's name"
                        className={errors.name ? "border-destructive" : ""}
                      />
                      {errors.name && <p className="text-sm text-destructive">{errors.name}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="age">Age (years) *</Label>
                      <Input
                        id="age"
                        type="number"
                        min="1"
                        max="18"
                        value={formData.age || ""}
                        onChange={(e) => updateField("age", parseFloat(e.target.value) || 0)}
                        placeholder="Enter age"
                        className={errors.age ? "border-destructive" : ""}
                      />
                      {errors.age && <p className="text-sm text-destructive">{errors.age}</p>}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-medium flex items-center gap-2">
                      <span className="w-6 h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm">2</span>
                      Measurements
                    </h3>
                    
                    <div className="space-y-2">
                      <Label htmlFor="height">Height (cm) *</Label>
                      <Input
                        id="height"
                        type="number"
                        min="1"
                        max="200"
                        step="0.1"
                        value={formData.height || ""}
                        onChange={(e) => updateField("height", parseFloat(e.target.value) || 0)}
                        placeholder="Enter height"
                        className={errors.height ? "border-destructive" : ""}
                      />
                      {errors.height && <p className="text-sm text-destructive">{errors.height}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="weight">Weight (kg) *</Label>
                      <Input
                        id="weight"
                        type="number"
                        min="1"
                        max="100"
                        step="0.1"
                        value={formData.weight || ""}
                        onChange={(e) => updateField("weight", parseFloat(e.target.value) || 0)}
                        placeholder="Enter weight"
                        className={errors.weight ? "border-destructive" : ""}
                      />
                      {errors.weight && <p className="text-sm text-destructive">{errors.weight}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="armCircumference">Mid-Upper Arm Circumference (cm) *</Label>
                      <Input
                        id="armCircumference"
                        type="number"
                        min="1"
                        max="30"
                        step="0.1"
                        value={formData.armCircumference || ""}
                        onChange={(e) => updateField("armCircumference", parseFloat(e.target.value) || 0)}
                        placeholder="Enter MUAC"
                        className={errors.armCircumference ? "border-destructive" : ""}
                      />
                      {errors.armCircumference && <p className="text-sm text-destructive">{errors.armCircumference}</p>}
                    </div>
                  </div>
                </div>

                {bmi && (
                  <Alert>
                    <Calculator className="h-4 w-4" />
                    <AlertDescription>
                      <strong>Calculated BMI:</strong> {bmi} kg/m²
                      {parseFloat(bmi) < 18.5 && " (Below normal range)"}
                    </AlertDescription>
                  </Alert>
                )}
              </TabsContent>

              <TabsContent value="growth" className="space-y-4 pt-4">
                <h3 className="text-lg font-medium">Growth & Development Concerns</h3>
                <p className="text-sm text-muted-foreground">Select any developmental concerns observed</p>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {milestoneOptions.map((option) => (
                    <div key={option.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={option.id}
                        checked={formData.milestonesConcerns?.includes(option.id)}
                        onCheckedChange={() => toggleArrayItem("milestonesConcerns", option.id)}
                      />
                      <Label htmlFor={option.id} className="text-sm cursor-pointer">
                        {option.label}
                      </Label>
                    </div>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="illness" className="space-y-4 pt-4">
                <h3 className="text-lg font-medium">Current Symptoms</h3>
                <p className="text-sm text-muted-foreground">Select any symptoms the child is experiencing</p>
                
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="temperature">Temperature (°C) - if fever present</Label>
                    <Input
                      id="temperature"
                      type="number"
                      min="35"
                      max="42"
                      step="0.1"
                      value={formData.temperature || ""}
                      onChange={(e) => updateField("temperature", parseFloat(e.target.value) || undefined)}
                      placeholder="Enter temperature if feverish"
                    />
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {symptomOptions.map((option) => (
                      <div key={option.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={option.id}
                          checked={formData.symptoms?.includes(option.id)}
                          onCheckedChange={() => toggleArrayItem("symptoms", option.id)}
                        />
                        <Label htmlFor={option.id} className="text-sm cursor-pointer">
                          {option.label}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="behavioral" className="space-y-4 pt-4">
                <h3 className="text-lg font-medium">Mental & Behavioral Observations</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="sleepHours">Average Sleep Hours</Label>
                      <Input
                        id="sleepHours"
                        type="number"
                        min="0"
                        max="24"
                        value={formData.sleepHours || ""}
                        onChange={(e) => updateField("sleepHours", parseFloat(e.target.value) || undefined)}
                        placeholder="Hours of sleep per night"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="appetite">Appetite Level</Label>
                      <Select
                        value={formData.appetiteLevel}
                        onValueChange={(value) => updateField("appetiteLevel", value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select appetite level" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="poor">Poor</SelectItem>
                          <SelectItem value="normal">Normal</SelectItem>
                          <SelectItem value="good">Good</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Behavioral Concerns</Label>
                    <div className="space-y-2">
                      {behavioralOptions.map((option) => (
                        <div key={option.id} className="flex items-center space-x-2">
                          <Checkbox
                            id={option.id}
                            checked={formData.behavioralObservations?.includes(option.id)}
                            onCheckedChange={() => toggleArrayItem("behavioralObservations", option.id)}
                          />
                          <Label htmlFor={option.id} className="text-sm cursor-pointer">
                            {option.label}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>

            {/* Additional Notes */}
            <div className="space-y-2">
              <Label htmlFor="notes">Additional Notes (Optional)</Label>
              <Textarea
                id="notes"
                value={formData.additionalNotes}
                onChange={(e) => updateField("additionalNotes", e.target.value)}
                placeholder="Any additional observations or relevant information..."
                rows={3}
              />
            </div>

            {/* Medical Disclaimer */}
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                <strong>Medical Disclaimer:</strong> This AI system provides assessment support only. 
                Always consult qualified healthcare professionals for diagnosis and treatment decisions.
              </AlertDescription>
            </Alert>

            {/* Submit Buttons */}
            <div className="flex justify-end gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={() => setFormData({
                  name: "",
                  age: 0,
                  height: 0,
                  weight: 0,
                  armCircumference: 0,
                  additionalNotes: "",
                  symptoms: [],
                  temperature: undefined,
                  milestonesConcerns: [],
                  behavioralObservations: [],
                  sleepHours: undefined,
                  appetiteLevel: "normal"
                })}
                disabled={isAnalyzing}
              >
                Clear Form
              </Button>
              <Button 
                type="submit" 
                disabled={isAnalyzing || completionPercentage < 100}
                className="bg-gradient-primary hover:opacity-90 min-w-32"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Calculator className="h-4 w-4 mr-2" />
                    Analyze Health
                  </>
                )}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Analysis Progress */}
      {isAnalyzing && (
        <Card className="medical-card">
          <CardContent className="py-8">
            <div className="text-center space-y-4">
              <div className="flex justify-center">
                <Loader2 className="h-12 w-12 text-primary animate-spin" />
              </div>
              <div className="space-y-2">
                <h3 className="text-lg font-medium">Comprehensive Health Analysis in Progress</h3>
                <p className="text-muted-foreground">
                  Analyzing nutrition, growth, illness symptoms, and behavioral patterns...
                </p>
              </div>
              <Progress value={75} className="max-w-xs mx-auto" />
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
