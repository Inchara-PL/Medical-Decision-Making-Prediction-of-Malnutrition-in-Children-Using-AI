import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Pause,
  MessageSquare,
  Loader2
} from "lucide-react";
import { ChildHealthData, ComprehensiveAnalysisResult } from "@/lib/healthAnalysis";

interface VoiceAssistantProps {
  childData: ChildHealthData | null;
  analysisResult: ComprehensiveAnalysisResult | null;
}

export function VoiceAssistant({ childData, analysisResult }: VoiceAssistantProps) {
  const [isListening, setIsListening] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [currentMessage, setCurrentMessage] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  // Simulated voice synthesis function
  const synthesizeVoice = async (text: string) => {
    setIsGenerating(true);
    setCurrentMessage(text);
    
    // In a real app, this would use ElevenLabs API
    // For now, we'll simulate the voice generation
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Create a simple text-to-speech using Web Speech API as fallback
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.9;
      utterance.pitch = 1.2; // Higher pitch for female voice
      utterance.volume = isMuted ? 0 : 1;
      
      // Try to select a female voice
      const voices = speechSynthesis.getVoices();
      const femaleVoice = voices.find(voice => 
        voice.name.toLowerCase().includes('female') ||
        voice.name.toLowerCase().includes('zira') ||
        voice.name.toLowerCase().includes('hazel')
      ) || voices.find(voice => voice.lang.startsWith('en'));
      
      if (femaleVoice) {
        utterance.voice = femaleVoice;
      }
      
      utterance.onstart = () => {
        setIsPlaying(true);
        setIsGenerating(false);
      };
      
      utterance.onend = () => {
        setIsPlaying(false);
      };
      
      speechSynthesis.speak(utterance);
    } else {
      setIsGenerating(false);
    }
  };

  const generateExplanation = () => {
    if (!childData && !analysisResult) {
      const welcomeText = `Hello! I'm your AI medical assistant. I can help explain comprehensive child health assessments including nutrition, growth, illness symptoms, and behavioral patterns. Please input child data to get started.`;
      synthesizeVoice(welcomeText);
      return;
    }

    let explanationText = "";

    if (childData && analysisResult) {
      const bmi = (childData.weight / ((childData.height / 100) ** 2)).toFixed(1);
      
      const alertCount = analysisResult.riskAlerts.length;
      const criticalCategories = analysisResult.categories.filter(c => c.status === "critical" || c.status === "concern");
      
      explanationText = `
        Hello! I've completed a comprehensive health analysis for ${childData.name}, a ${childData.age} year old child.
        
        Here are the key measurements: Height is ${childData.height} centimeters, weight is ${childData.weight} kilograms, 
        giving a BMI of ${bmi}. The mid-upper arm circumference is ${childData.armCircumference} centimeters.
        
        Overall health status is assessed as ${analysisResult.overallRiskLevel} risk with ${analysisResult.confidence}% confidence.
        
        ${alertCount > 0 ? `There are ${alertCount} health alerts that need attention.` : 'No urgent health alerts were detected.'}
        
        ${criticalCategories.length > 0 
          ? `Areas of concern include: ${criticalCategories.map(c => c.category).join(', ')}.` 
          : 'All health categories show healthy indicators.'}
        
        The main recommendations are: ${analysisResult.recommendations.slice(0, 3).join('. ')}.
        
        ${analysisResult.overallRiskLevel === 'high' 
          ? 'This indicates an urgent need for medical intervention.' 
          : analysisResult.overallRiskLevel === 'moderate' 
          ? 'Close monitoring and follow-up are recommended.' 
          : 'The child shows healthy indicators. Continue with regular check-ups.'}
        
        Please consult with qualified healthcare professionals for complete assessment and treatment planning.
      `;
    } else if (childData) {
      explanationText = `I can see data has been entered for ${childData.name}. The measurements show a height of ${childData.height} cm, 
      weight of ${childData.weight} kg, and arm circumference of ${childData.armCircumference} cm. 
      Please complete the analysis to get detailed health assessment results.`;
    }

    synthesizeVoice(explanationText.trim());
  };

  const toggleListening = () => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      setIsListening(!isListening);
      // Speech recognition would be implemented here
    } else {
      alert('Speech recognition is not supported in this browser');
    }
  };

  const stopPlayback = () => {
    if ('speechSynthesis' in window) {
      speechSynthesis.cancel();
    }
    setIsPlaying(false);
    setCurrentMessage("");
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Expanded Card */}
      {isExpanded && (
        <Card className="mb-4 w-80 medical-card animate-slide-up">
          <CardContent className="p-4 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-medium flex items-center gap-2">
                <Volume2 className="h-4 w-4 text-primary" />
                AI Voice Assistant
              </h3>
              <Badge variant="secondary" className="text-xs">
                Female Voice
              </Badge>
            </div>

            {currentMessage && (
              <div className="text-sm text-muted-foreground p-3 bg-muted/50 rounded-lg">
                {currentMessage}
              </div>
            )}

            <div className="grid grid-cols-2 gap-2">
              <Button
                onClick={generateExplanation}
                disabled={isGenerating || isPlaying}
                variant="secondary"
                size="sm"
                className="flex items-center gap-2"
              >
                {isGenerating ? (
                  <Loader2 className="h-3 w-3 animate-spin" />
                ) : (
                  <MessageSquare className="h-3 w-3" />
                )}
                Explain Data
              </Button>

              <Button
                onClick={toggleListening}
                variant={isListening ? "destructive" : "outline"}
                size="sm"
                className="flex items-center gap-2"
              >
                {isListening ? (
                  <MicOff className="h-3 w-3" />
                ) : (
                  <Mic className="h-3 w-3" />
                )}
                {isListening ? "Stop" : "Listen"}
              </Button>
            </div>

            {isPlaying && (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-primary rounded-full animate-pulse"></div>
                  <span className="text-sm text-primary">Speaking...</span>
                </div>
                <Button onClick={stopPlayback} variant="ghost" size="sm">
                  <Pause className="h-3 w-3" />
                </Button>
              </div>
            )}

            <Button
              onClick={() => setIsMuted(!isMuted)}
              variant="ghost"
              size="sm"
              className="w-full flex items-center gap-2"
            >
              {isMuted ? (
                <VolumeX className="h-3 w-3" />
              ) : (
                <Volume2 className="h-3 w-3" />
              )}
              {isMuted ? "Unmute" : "Mute"} Audio
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Floating Action Button */}
      <Button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-14 h-14 rounded-full bg-gradient-primary shadow-[var(--shadow-glow)] hover:opacity-90 transition-all duration-300"
        size="lg"
      >
        {isGenerating ? (
          <Loader2 className="h-6 w-6 animate-spin" />
        ) : isPlaying ? (
          <Volume2 className="h-6 w-6" />
        ) : (
          <Mic className="h-6 w-6" />
        )}
      </Button>
    </div>
  );
}