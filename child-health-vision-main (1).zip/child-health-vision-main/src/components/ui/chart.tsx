import * as React from "react";
import { cn } from "@/lib/utils";

// Simple placeholder chart component since we removed recharts
// This can be enhanced with actual chart libraries when needed

interface ChartConfig {
  [key: string]: {
    label?: string;
    icon?: React.ComponentType;
    color?: string;
    theme?: {
      light?: string;
      dark?: string;
    };
  };
}

interface ChartContainerProps {
  config: ChartConfig;
  children: React.ComponentProps<"div">["children"];
  className?: string;
}

const ChartContainer = React.forwardRef<HTMLDivElement, ChartContainerProps>(
  ({ config, children, className, ...props }, ref) => {
    return (
      <div
        ref={ref}
        data-chart={JSON.stringify(config)}
        className={cn("flex aspect-video justify-center text-xs", className)}
        {...props}
      >
        {children}
      </div>
    );
  }
);

ChartContainer.displayName = "ChartContainer";

interface ChartTooltipContentProps {
  active?: boolean;
  payload?: any[];
  label?: string;
  labelFormatter?: (value: any, payload: any[]) => React.ReactNode;
  formatter?: (value: any, name: any, props: any) => React.ReactNode;
  className?: string;
  indicator?: "line" | "dot" | "dashed";
  hideLabel?: boolean;
  hideIndicator?: boolean;
  labelClassName?: string;
  color?: string;
  nameKey?: string;
  labelKey?: string;
}

const ChartTooltipContent = React.forwardRef<
  HTMLDivElement,
  ChartTooltipContentProps
>(
  (
    {
      active,
      payload,
      className,
      indicator = "dot",
      hideLabel = false,
      hideIndicator = false,
      label,
      labelFormatter,
      labelClassName,
      formatter,
      color,
      nameKey,
      labelKey,
    },
    ref
  ) => {
    if (!active || !payload?.length) {
      return null;
    }

    return (
      <div
        ref={ref}
        className={cn(
          "grid min-w-[8rem] items-start gap-1.5 rounded-lg border border-border/50 bg-background px-2.5 py-1.5 text-xs shadow-xl",
          className
        )}
      >
        {!hideLabel && label && (
          <div className={cn("font-medium", labelClassName)}>
            {labelFormatter ? labelFormatter(label, payload) : label}
          </div>
        )}
        <div className="grid gap-1.5">
          {payload.map((item, index) => (
            <div
              key={`${item.dataKey || item.name || "item"}-${index}`}
              className="flex w-full flex-wrap items-stretch gap-2 [&>svg]:h-2.5 [&>svg]:w-2.5 [&>svg]:text-muted-foreground"
            >
              {!hideIndicator && (
                <div
                  className={cn("shrink-0 rounded-[2px]", {
                    "h-2.5 w-2.5": indicator === "dot",
                    "w-1": indicator === "line",
                    "w-0 border-l-2 border-dashed border-current": indicator === "dashed",
                  })}
                  style={{
                    backgroundColor: item.color || color,
                    borderColor: item.color || color,
                  }}
                />
              )}
              <div className="flex flex-1 justify-between leading-none">
                <div className="grid gap-1.5">
                  <span className="text-muted-foreground">
                    {formatter
                      ? formatter(item.value, item.name || item.dataKey, item)
                      : item.name || item.dataKey}
                  </span>
                </div>
                <span className="font-mono font-medium tabular-nums text-foreground">
                  {typeof item.value === "number"
                    ? item.value.toLocaleString()
                    : item.value}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }
);

ChartTooltipContent.displayName = "ChartTooltipContent";

const ChartLegend = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement> & {
    payload?: any[];
    verticalAlign?: string;
  }
>(({ className, payload, verticalAlign, ...props }, ref) => {
  if (!payload?.length) {
    return null;
  }

  return (
    <div
      ref={ref}
      className={cn("flex items-center justify-center gap-4", className)}
      {...props}
    >
      {payload.map((item, index) => (
        <div
          key={`${item.value || item.dataKey || "item"}-${index}`}
          className="flex items-center gap-1.5 [&>svg]:h-3 [&>svg]:w-3 [&>svg]:text-muted-foreground"
        >
          <div
            className="h-2 w-2 shrink-0 rounded-[2px]"
            style={{
              backgroundColor: item.color,
            }}
          />
          <span className="text-muted-foreground">{item.value}</span>
        </div>
      ))}
    </div>
  );
});

ChartLegend.displayName = "ChartLegend";

// Chart style utilities
const ChartStyle = ({ id, config }: { id: string; config: ChartConfig }) => {
  const colorConfig = Object.entries(config).reduce(
    (colors, [key, keyConfig]) => {
      const lightColor = keyConfig.theme?.light || keyConfig.color;
      const darkColor = keyConfig.theme?.dark || keyConfig.color;
      
      if (lightColor) {
        colors[key] = { light: lightColor, dark: darkColor };
      }
      return colors;
    },
    {} as Record<string, { light: string; dark?: string }>
  );

  return (
    <style
      dangerouslySetInnerHTML={{
        __html: Object.entries(colorConfig)
          .map(
            ([key, { light, dark }]) =>
              `
  [data-chart="${id}"] {
    --color-${key}: ${light};
  }
  .dark [data-chart="${id}"] {
    --color-${key}: ${dark ?? light};
  }
`
          )
          .join(""),
      }}
    />
  );
};

export {
  ChartContainer,
  ChartTooltipContent,
  ChartLegend,
  ChartStyle,
  type ChartConfig,
};