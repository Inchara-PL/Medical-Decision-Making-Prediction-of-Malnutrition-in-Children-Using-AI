import { MedicalDashboard } from "@/components/medical/MedicalDashboard";

const Index = () => {
  return <MedicalDashboard />;
};

export default Index;
