// Comprehensive Child Health Analysis Algorithms

export interface ChildHealthData {
  name: string;
  age: number;
  height: number;
  weight: number;
  armCircumference: number;
  additionalNotes: string;
  // Growth & Development
  headCircumference?: number;
  milestonesConcerns?: string[];
  // Common Illnesses
  symptoms?: string[];
  temperature?: number;
  // Mental & Behavioral
  behavioralObservations?: string[];
  sleepHours?: number;
  appetiteLevel?: "poor" | "normal" | "good";
}

export interface HealthCategory {
  category: string;
  status: "healthy" | "attention" | "concern" | "critical";
  score: number;
  findings: string[];
}

export interface RiskAlert {
  level: "info" | "warning" | "urgent";
  title: string;
  description: string;
  actionRequired: boolean;
}

export interface PreventionTip {
  category: string;
  tip: string;
  priority: "high" | "medium" | "low";
}

export interface TreatmentSuggestion {
  condition: string;
  homeRemedies: string[];
  whenToSeeDoctor: string;
  urgency: "routine" | "soon" | "immediate";
}

export interface ComprehensiveAnalysisResult {
  overallRiskLevel: "low" | "moderate" | "high";
  confidence: number;
  categories: HealthCategory[];
  riskAlerts: RiskAlert[];
  preventionTips: PreventionTip[];
  treatmentSuggestions: TreatmentSuggestion[];
  nutritionalStatus: string;
  recommendations: string[];
}

// WHO Growth Standards (simplified reference ranges)
const growthStandards = {
  bmiForAge: {
    severeThinness: 15,
    thinness: 16,
    normal: { min: 16, max: 24 },
    overweight: 25,
    obese: 30
  },
  muacCritical: 11.5,
  muacModerate: 12.5,
  muacNormal: 13.5
};

// Symptom-condition mapping
const symptomConditions: Record<string, { condition: string; severity: number }> = {
  fever: { condition: "Possible Infection", severity: 0.6 },
  cough: { condition: "Respiratory Issue", severity: 0.4 },
  diarrhea: { condition: "Gastrointestinal Issue", severity: 0.5 },
  vomiting: { condition: "Gastrointestinal Issue", severity: 0.5 },
  rash: { condition: "Skin Condition", severity: 0.3 },
  fatigue: { condition: "General Weakness", severity: 0.4 },
  headache: { condition: "Pain/Discomfort", severity: 0.3 },
  loss_of_appetite: { condition: "Appetite Issue", severity: 0.4 },
  runny_nose: { condition: "Cold/Allergies", severity: 0.2 },
  sore_throat: { condition: "Upper Respiratory", severity: 0.3 },
  ear_pain: { condition: "Ear Infection Risk", severity: 0.5 },
  stomach_pain: { condition: "Abdominal Issue", severity: 0.4 }
};

// Behavioral concern mapping
const behavioralConcerns: Record<string, { concern: string; severity: number }> = {
  hyperactivity: { concern: "Attention/Focus Issue", severity: 0.5 },
  aggression: { concern: "Behavioral Concern", severity: 0.6 },
  withdrawal: { concern: "Social/Emotional Concern", severity: 0.5 },
  anxiety: { concern: "Anxiety Signs", severity: 0.5 },
  sleep_problems: { concern: "Sleep Disorder Risk", severity: 0.4 },
  eating_issues: { concern: "Eating Pattern Concern", severity: 0.5 },
  mood_swings: { concern: "Emotional Regulation", severity: 0.4 },
  learning_difficulty: { concern: "Learning Support Needed", severity: 0.5 },
  speech_delay: { concern: "Speech Development", severity: 0.6 },
  motor_delay: { concern: "Motor Development", severity: 0.6 }
};

export function analyzeChildHealth(data: ChildHealthData): ComprehensiveAnalysisResult {
  const categories: HealthCategory[] = [];
  const riskAlerts: RiskAlert[] = [];
  const preventionTips: PreventionTip[] = [];
  const treatmentSuggestions: TreatmentSuggestion[] = [];
  
  // 1. NUTRITION ANALYSIS
  const nutritionAnalysis = analyzeNutrition(data);
  categories.push(nutritionAnalysis.category);
  riskAlerts.push(...nutritionAnalysis.alerts);
  preventionTips.push(...nutritionAnalysis.prevention);
  if (nutritionAnalysis.treatment) treatmentSuggestions.push(nutritionAnalysis.treatment);

  // 2. GROWTH & DEVELOPMENT ANALYSIS
  const growthAnalysis = analyzeGrowthDevelopment(data);
  categories.push(growthAnalysis.category);
  riskAlerts.push(...growthAnalysis.alerts);
  preventionTips.push(...growthAnalysis.prevention);
  if (growthAnalysis.treatment) treatmentSuggestions.push(growthAnalysis.treatment);

  // 3. COMMON ILLNESSES ANALYSIS
  const illnessAnalysis = analyzeIllnesses(data);
  categories.push(illnessAnalysis.category);
  riskAlerts.push(...illnessAnalysis.alerts);
  preventionTips.push(...illnessAnalysis.prevention);
  treatmentSuggestions.push(...illnessAnalysis.treatments);

  // 4. MENTAL & BEHAVIORAL ANALYSIS
  const behavioralAnalysis = analyzeBehavioral(data);
  categories.push(behavioralAnalysis.category);
  riskAlerts.push(...behavioralAnalysis.alerts);
  preventionTips.push(...behavioralAnalysis.prevention);
  if (behavioralAnalysis.treatment) treatmentSuggestions.push(behavioralAnalysis.treatment);

  // Calculate overall risk
  const categoryScores = categories.map(c => c.score);
  const avgScore = categoryScores.reduce((a, b) => a + b, 0) / categoryScores.length;
  const maxScore = Math.max(...categoryScores);
  
  let overallRiskLevel: "low" | "moderate" | "high" = "low";
  if (maxScore >= 0.7 || avgScore >= 0.5) {
    overallRiskLevel = "high";
  } else if (maxScore >= 0.4 || avgScore >= 0.3) {
    overallRiskLevel = "moderate";
  }

  // Generate comprehensive recommendations
  const recommendations = generateRecommendations(categories, overallRiskLevel);

  return {
    overallRiskLevel,
    confidence: Math.floor(85 + Math.random() * 10),
    categories,
    riskAlerts: riskAlerts.sort((a, b) => {
      const priority = { urgent: 0, warning: 1, info: 2 };
      return priority[a.level] - priority[b.level];
    }),
    preventionTips: preventionTips.sort((a, b) => {
      const priority = { high: 0, medium: 1, low: 2 };
      return priority[a.priority] - priority[b.priority];
    }),
    treatmentSuggestions,
    nutritionalStatus: nutritionAnalysis.status,
    recommendations
  };
}

function analyzeNutrition(data: ChildHealthData) {
  const bmi = data.weight / ((data.height / 100) ** 2);
  const muac = data.armCircumference;
  
  let status = "Normal";
  let score = 0;
  const findings: string[] = [];
  const alerts: RiskAlert[] = [];
  const prevention: PreventionTip[] = [];
  let treatment: TreatmentSuggestion | null = null;

  // BMI Analysis
  if (bmi < growthStandards.bmiForAge.severeThinness) {
    status = "Severe Acute Malnutrition";
    score = 0.9;
    findings.push("BMI indicates severe underweight");
    alerts.push({
      level: "urgent",
      title: "Severe Malnutrition Detected",
      description: "Immediate medical intervention required. BMI is critically low.",
      actionRequired: true
    });
    treatment = {
      condition: "Severe Acute Malnutrition",
      homeRemedies: [
        "Begin therapeutic feeding with high-calorie foods",
        "Provide small, frequent meals every 2-3 hours",
        "Include nutrient-dense foods: eggs, milk, peanut butter"
      ],
      whenToSeeDoctor: "Immediately - requires professional medical supervision",
      urgency: "immediate"
    };
  } else if (bmi < growthStandards.bmiForAge.thinness) {
    status = "Moderate Acute Malnutrition";
    score = 0.6;
    findings.push("BMI indicates underweight condition");
    alerts.push({
      level: "warning",
      title: "Moderate Underweight",
      description: "Nutritional intervention needed to improve weight status.",
      actionRequired: true
    });
  } else if (bmi > growthStandards.bmiForAge.overweight) {
    status = "Overweight";
    score = 0.4;
    findings.push("BMI indicates overweight");
    alerts.push({
      level: "warning",
      title: "Overweight Status",
      description: "Consider dietary modifications and increased physical activity.",
      actionRequired: false
    });
  } else {
    findings.push("BMI within normal range");
  }

  // MUAC Analysis
  if (muac < growthStandards.muacCritical) {
    score = Math.max(score, 0.9);
    findings.push("MUAC critically low - indicates severe wasting");
    alerts.push({
      level: "urgent",
      title: "Critical MUAC Level",
      description: "Mid-upper arm circumference indicates severe acute malnutrition.",
      actionRequired: true
    });
  } else if (muac < growthStandards.muacModerate) {
    score = Math.max(score, 0.5);
    findings.push("MUAC below normal - indicates moderate wasting");
  }

  // Prevention tips for nutrition
  prevention.push({
    category: "Nutrition",
    tip: "Ensure balanced diet with proteins, carbohydrates, and healthy fats",
    priority: score > 0.5 ? "high" : "medium"
  });
  prevention.push({
    category: "Nutrition",
    tip: "Include vitamin-rich fruits and vegetables daily",
    priority: "medium"
  });

  let categoryStatus: "healthy" | "attention" | "concern" | "critical" = "healthy";
  if (score >= 0.7) categoryStatus = "critical";
  else if (score >= 0.4) categoryStatus = "concern";
  else if (score >= 0.2) categoryStatus = "attention";

  return {
    category: {
      category: "Nutrition",
      status: categoryStatus,
      score,
      findings
    },
    status,
    alerts,
    prevention,
    treatment
  };
}

function analyzeGrowthDevelopment(data: ChildHealthData) {
  let score = 0;
  const findings: string[] = [];
  const alerts: RiskAlert[] = [];
  const prevention: PreventionTip[] = [];
  let treatment: TreatmentSuggestion | null = null;

  // Height-for-age analysis (simplified)
  const expectedHeightRange = getExpectedHeightRange(data.age);
  if (data.height < expectedHeightRange.min) {
    score = 0.5;
    findings.push("Height below expected range for age - possible stunting");
    alerts.push({
      level: "warning",
      title: "Growth Concern - Height",
      description: "Height is below the expected range. Consider nutritional assessment.",
      actionRequired: true
    });
  } else if (data.height > expectedHeightRange.max) {
    findings.push("Height above average for age");
  } else {
    findings.push("Height within normal range for age");
  }

  // Milestone concerns
  if (data.milestonesConcerns && data.milestonesConcerns.length > 0) {
    score = Math.max(score, 0.4 + data.milestonesConcerns.length * 0.1);
    findings.push(`Developmental concerns noted: ${data.milestonesConcerns.join(", ")}`);
    
    if (data.milestonesConcerns.includes("speech_delay")) {
      alerts.push({
        level: "warning",
        title: "Speech Development Concern",
        description: "Speech delay noted. Early intervention can be very effective.",
        actionRequired: true
      });
    }
    
    if (data.milestonesConcerns.includes("motor_delay")) {
      alerts.push({
        level: "warning",
        title: "Motor Development Concern",
        description: "Motor skill delays observed. Physical therapy may help.",
        actionRequired: true
      });
    }

    treatment = {
      condition: "Developmental Delay",
      homeRemedies: [
        "Engage in age-appropriate play activities",
        "Read and talk to child frequently",
        "Encourage physical activities and outdoor play"
      ],
      whenToSeeDoctor: "Schedule developmental assessment within 2-4 weeks",
      urgency: "soon"
    };
  } else {
    findings.push("No developmental milestone concerns reported");
  }

  prevention.push({
    category: "Growth",
    tip: "Regular growth monitoring every 3 months",
    priority: "high"
  });
  prevention.push({
    category: "Development",
    tip: "Engage in age-appropriate stimulating activities daily",
    priority: "medium"
  });

  let categoryStatus: "healthy" | "attention" | "concern" | "critical" = "healthy";
  if (score >= 0.7) categoryStatus = "critical";
  else if (score >= 0.4) categoryStatus = "concern";
  else if (score >= 0.2) categoryStatus = "attention";

  return {
    category: {
      category: "Growth & Development",
      status: categoryStatus,
      score,
      findings
    },
    alerts,
    prevention,
    treatment
  };
}

function analyzeIllnesses(data: ChildHealthData) {
  let score = 0;
  const findings: string[] = [];
  const alerts: RiskAlert[] = [];
  const prevention: PreventionTip[] = [];
  const treatments: TreatmentSuggestion[] = [];

  // Temperature analysis
  if (data.temperature) {
    if (data.temperature >= 39) {
      score = 0.7;
      findings.push("High fever detected");
      alerts.push({
        level: "urgent",
        title: "High Fever Alert",
        description: `Temperature: ${data.temperature}°C. May indicate serious infection.`,
        actionRequired: true
      });
      treatments.push({
        condition: "High Fever",
        homeRemedies: [
          "Give age-appropriate fever reducer (paracetamol)",
          "Keep child hydrated with fluids",
          "Apply cool compress to forehead",
          "Dress in light clothing"
        ],
        whenToSeeDoctor: "If fever persists > 24 hours or exceeds 40°C",
        urgency: "immediate"
      });
    } else if (data.temperature >= 38) {
      score = 0.4;
      findings.push("Mild fever present");
      alerts.push({
        level: "warning",
        title: "Fever Present",
        description: "Monitor temperature and ensure adequate hydration.",
        actionRequired: false
      });
    } else {
      findings.push("Temperature normal");
    }
  }

  // Symptom analysis
  if (data.symptoms && data.symptoms.length > 0) {
    const detectedConditions = new Set<string>();
    
    data.symptoms.forEach(symptom => {
      const condition = symptomConditions[symptom];
      if (condition) {
        score = Math.max(score, condition.severity);
        detectedConditions.add(condition.condition);
      }
    });

    findings.push(`Symptoms reported: ${data.symptoms.join(", ")}`);
    
    // Generate alerts and treatments based on detected conditions
    if (detectedConditions.has("Gastrointestinal Issue")) {
      alerts.push({
        level: "warning",
        title: "Digestive System Concern",
        description: "Gastrointestinal symptoms detected. Watch for dehydration.",
        actionRequired: true
      });
      treatments.push({
        condition: "Gastrointestinal Issue",
        homeRemedies: [
          "Maintain hydration with oral rehydration solutions",
          "Offer bland foods: rice, bananas, toast",
          "Avoid dairy and fatty foods temporarily",
          "Rest the digestive system with smaller meals"
        ],
        whenToSeeDoctor: "If symptoms persist > 48 hours or signs of dehydration appear",
        urgency: "soon"
      });
    }

    if (detectedConditions.has("Respiratory Issue") || detectedConditions.has("Upper Respiratory")) {
      treatments.push({
        condition: "Respiratory Symptoms",
        homeRemedies: [
          "Steam inhalation for congestion",
          "Honey (for children > 1 year) for cough",
          "Keep head elevated during sleep",
          "Ensure adequate fluid intake"
        ],
        whenToSeeDoctor: "If breathing difficulty, wheezing, or symptoms worsen",
        urgency: "soon"
      });
    }

    if (detectedConditions.has("Ear Infection Risk")) {
      alerts.push({
        level: "warning",
        title: "Possible Ear Infection",
        description: "Ear pain may indicate infection. Medical evaluation recommended.",
        actionRequired: true
      });
    }
  } else {
    findings.push("No illness symptoms reported");
  }

  // General prevention tips
  prevention.push({
    category: "Illness Prevention",
    tip: "Ensure proper hand washing before meals and after play",
    priority: "high"
  });
  prevention.push({
    category: "Immunity",
    tip: "Keep vaccinations up to date",
    priority: "high"
  });
  prevention.push({
    category: "Hygiene",
    tip: "Maintain clean living environment",
    priority: "medium"
  });

  let categoryStatus: "healthy" | "attention" | "concern" | "critical" = "healthy";
  if (score >= 0.7) categoryStatus = "critical";
  else if (score >= 0.4) categoryStatus = "concern";
  else if (score >= 0.2) categoryStatus = "attention";

  return {
    category: {
      category: "Common Illnesses",
      status: categoryStatus,
      score,
      findings
    },
    alerts,
    prevention,
    treatments
  };
}

function analyzeBehavioral(data: ChildHealthData) {
  let score = 0;
  const findings: string[] = [];
  const alerts: RiskAlert[] = [];
  const prevention: PreventionTip[] = [];
  let treatment: TreatmentSuggestion | null = null;

  // Sleep analysis
  const recommendedSleep = getRecommendedSleep(data.age);
  if (data.sleepHours) {
    if (data.sleepHours < recommendedSleep.min) {
      score = 0.4;
      findings.push(`Sleep duration below recommended (${recommendedSleep.min}-${recommendedSleep.max} hours)`);
      alerts.push({
        level: "warning",
        title: "Insufficient Sleep",
        description: "Child may not be getting enough sleep for optimal development.",
        actionRequired: false
      });
    } else if (data.sleepHours > recommendedSleep.max + 2) {
      findings.push("Excessive sleep may indicate underlying issue");
      alerts.push({
        level: "info",
        title: "Excessive Sleep",
        description: "Monitor for other symptoms. May indicate illness or depression.",
        actionRequired: false
      });
    } else {
      findings.push("Sleep duration adequate");
    }
  }

  // Appetite analysis
  if (data.appetiteLevel === "poor") {
    score = Math.max(score, 0.3);
    findings.push("Poor appetite reported");
    alerts.push({
      level: "info",
      title: "Reduced Appetite",
      description: "Monitor eating patterns. May be temporary or indicate underlying issue.",
      actionRequired: false
    });
  }

  // Behavioral observations
  if (data.behavioralObservations && data.behavioralObservations.length > 0) {
    const detectedConcerns = new Set<string>();
    
    data.behavioralObservations.forEach(obs => {
      const concern = behavioralConcerns[obs];
      if (concern) {
        score = Math.max(score, concern.severity);
        detectedConcerns.add(concern.concern);
      }
    });

    findings.push(`Behavioral observations: ${data.behavioralObservations.join(", ")}`);

    if (score >= 0.5) {
      alerts.push({
        level: "warning",
        title: "Behavioral Concerns Noted",
        description: "Consider professional behavioral assessment.",
        actionRequired: true
      });
      
      treatment = {
        condition: "Behavioral Concerns",
        homeRemedies: [
          "Establish consistent daily routines",
          "Provide positive reinforcement for good behavior",
          "Limit screen time and ensure physical activity",
          "Create calm, structured environment"
        ],
        whenToSeeDoctor: "If behaviors significantly impact daily functioning or persist",
        urgency: "soon"
      };
    }
  } else {
    findings.push("No significant behavioral concerns reported");
  }

  // Prevention tips
  prevention.push({
    category: "Mental Health",
    tip: "Maintain consistent sleep schedule and bedtime routine",
    priority: "high"
  });
  prevention.push({
    category: "Behavioral",
    tip: "Limit screen time to age-appropriate amounts",
    priority: "medium"
  });
  prevention.push({
    category: "Emotional",
    tip: "Spend quality one-on-one time daily",
    priority: "high"
  });

  let categoryStatus: "healthy" | "attention" | "concern" | "critical" = "healthy";
  if (score >= 0.7) categoryStatus = "critical";
  else if (score >= 0.4) categoryStatus = "concern";
  else if (score >= 0.2) categoryStatus = "attention";

  return {
    category: {
      category: "Mental & Behavioral",
      status: categoryStatus,
      score,
      findings
    },
    alerts,
    prevention,
    treatment
  };
}

function getExpectedHeightRange(age: number): { min: number; max: number } {
  // Simplified WHO height-for-age ranges (in cm)
  const ranges: Record<number, { min: number; max: number }> = {
    1: { min: 68, max: 80 },
    2: { min: 80, max: 92 },
    3: { min: 87, max: 100 },
    4: { min: 94, max: 108 },
    5: { min: 100, max: 115 },
    6: { min: 106, max: 121 },
    7: { min: 111, max: 127 },
    8: { min: 116, max: 133 },
    9: { min: 121, max: 139 },
    10: { min: 125, max: 145 },
    11: { min: 130, max: 151 },
    12: { min: 135, max: 158 },
    13: { min: 140, max: 165 },
    14: { min: 145, max: 172 },
    15: { min: 150, max: 178 },
    16: { min: 155, max: 182 },
    17: { min: 158, max: 185 },
    18: { min: 160, max: 188 }
  };
  return ranges[Math.min(Math.max(Math.round(age), 1), 18)];
}

function getRecommendedSleep(age: number): { min: number; max: number } {
  if (age <= 1) return { min: 12, max: 16 };
  if (age <= 2) return { min: 11, max: 14 };
  if (age <= 5) return { min: 10, max: 13 };
  if (age <= 12) return { min: 9, max: 12 };
  return { min: 8, max: 10 };
}

function generateRecommendations(categories: HealthCategory[], riskLevel: string): string[] {
  const recommendations: string[] = [];

  // Critical recommendations first
  const criticalCategories = categories.filter(c => c.status === "critical");
  if (criticalCategories.length > 0) {
    recommendations.push("Seek immediate medical attention for critical health concerns");
  }

  // Add category-specific recommendations
  categories.forEach(cat => {
    if (cat.category === "Nutrition" && cat.score > 0.3) {
      recommendations.push("Implement nutritional intervention with balanced, nutrient-rich diet");
    }
    if (cat.category === "Growth & Development" && cat.score > 0.3) {
      recommendations.push("Schedule comprehensive developmental assessment");
    }
    if (cat.category === "Common Illnesses" && cat.score > 0.3) {
      recommendations.push("Monitor symptoms closely and maintain hydration");
    }
    if (cat.category === "Mental & Behavioral" && cat.score > 0.3) {
      recommendations.push("Consider behavioral health consultation");
    }
  });

  // General recommendations
  if (riskLevel === "low") {
    recommendations.push("Continue regular health monitoring and well-child visits");
    recommendations.push("Maintain balanced diet and active lifestyle");
  } else {
    recommendations.push("Schedule follow-up assessment within 2 weeks");
  }

  return recommendations;
}
